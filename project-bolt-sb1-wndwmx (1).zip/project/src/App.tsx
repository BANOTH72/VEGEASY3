import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Twitter, MessageCircle, Send, Copyright, Instagram } from 'lucide-react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import VendorDashboard from './pages/VendorDashboard';
import CustomerDashboard from './pages/CustomerDashboard';
import RiderDashboard from './pages/RiderDashboard';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/vendor" element={<VendorDashboard />} />
            <Route path="/customer" element={<CustomerDashboard />} />
            <Route path="/rider" element={<RiderDashboard />} />
          </Routes>
        </div>
        <footer className="bg-green-600 text-white py-6 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <div className="flex items-center space-x-2">
                <Copyright className="h-4 w-4" />
                <span>2024 BANOTH HARI CHANDRA PRASAD. All rights reserved.</span>
              </div>
              <div className="flex space-x-6">
                <a
                  href="https://www.instagram.com/mr_devil_dude_18?igsh=NTc4MTIwNjQ2YQ=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-green-200 transition-colors"
                >
                  <Instagram className="h-6 w-6" />
                </a>
                <a
                  href="https://x.com/mr_devil_dude18?t=lUOra_9O2YYW4vDgs82ScQ&s=09"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-green-200 transition-colors"
                >
                  <Twitter className="h-6 w-6" />
                </a>
                <a
                  href="https://t.me/Mr_devil_dude_18"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-green-200 transition-colors"
                >
                  <Send className="h-6 w-6" />
                </a>
                <a
                  href="https://wa.me/919010334633"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-green-200 transition-colors"
                >
                  <MessageCircle className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;