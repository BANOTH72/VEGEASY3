import React, { useState } from 'react';
import { Search, ShoppingCart } from 'lucide-react';

export default function CustomerDashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState([]);

  const vegetables = [
    {
      id: 1,
      name: 'Tomatoes',
      price: 40,
      unit: 'kg',
      vendor: 'Fresh Farm Vegetables',
      image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 2,
      name: 'Potatoes',
      price: 30,
      unit: 'kg',
      vendor: 'Green Market',
      image: 'https://images.unsplash.com/photo-1590165482129-1b8b27698780?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 3,
      name: 'Onions',
      price: 35,
      unit: 'kg',
      vendor: 'Local Harvest',
      image: 'https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 4,
      name: 'Carrots',
      price: 45,
      unit: 'kg',
      vendor: 'Fresh Farm Vegetables',
      image: 'https://images.unsplash.com/photo-1447175008436-054170c2e979?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 5,
      name: 'Cauliflower',
      price: 50,
      unit: 'piece',
      vendor: 'Green Market',
      image: 'https://images.unsplash.com/photo-1613743983303-b3e89f8a2b80?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 6,
      name: 'Green Peas',
      price: 60,
      unit: 'kg',
      vendor: 'Local Harvest',
      image: 'https://images.unsplash.com/photo-1587735243615-c03f25aaff15?auto=format&fit=crop&w=600&q=80'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Find Fresh Vegetables</h1>
        <div className="relative">
          <ShoppingCart className="h-6 w-6 text-green-600" />
          <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
            {cart.length}
          </span>
        </div>
      </div>

      <div className="mb-8">
        <div className="relative">
          <input
            type="text"
            placeholder="Search for vegetables..."
            className="w-full px-4 py-2 pl-10 pr-4 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {vegetables.map((veg) => (
          <div key={veg.id} className="bg-white rounded-lg shadow-md overflow-hidden transform hover:scale-105 transition-transform">
            <img
              src={veg.image}
              alt={veg.name}
              className="w-full h-48 object-cover"
              loading="lazy"
            />
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-lg">{veg.name}</h3>
                  <p className="text-green-600 font-semibold">₹{veg.price}/{veg.unit}</p>
                  <p className="text-sm text-gray-500">{veg.vendor}</p>
                </div>
              </div>
              <button className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}