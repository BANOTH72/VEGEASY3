import React from 'react';
import { Navigation, Clock, IndianRupee, MapPin } from 'lucide-react';

export default function RiderDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Rider Dashboard</h1>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Navigation className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Active Deliveries</h2>
          <p className="text-3xl font-bold">3</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Clock className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Today's Hours</h2>
          <p className="text-3xl font-bold">6.5</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <IndianRupee className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Today's Earnings</h2>
          <p className="text-3xl font-bold">₹850</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Current Deliveries</h2>
          <div className="space-y-4">
            <div className="border-l-4 border-green-600 pl-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">Order #DEL001</span>
                <span className="text-green-600">₹120</span>
              </div>
              <p className="text-sm text-gray-600">Pickup: Farm beside SR&BGNR College</p>
              <p className="text-sm text-gray-600">Delivery: Gol Thanda, Khammam</p>
              <div className="mt-2 flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="text-sm text-gray-600">2.5 km away</span>
              </div>
              <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Start Navigation
              </button>
            </div>
            <div className="border-l-4 border-yellow-600 pl-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">Order #DEL002</span>
                <span className="text-green-600">₹90</span>
              </div>
              <p className="text-sm text-gray-600">Pickup: Farm near Patel Stadium</p>
              <p className="text-sm text-gray-600">Delivery: Khammam City</p>
              <div className="mt-2 flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="text-sm text-gray-600">1.8 km away</span>
              </div>
              <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Start Navigation
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Delivery Area</h2>
          <div className="relative w-full h-[400px] rounded-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&q=80"
              alt="Khammam District Map"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            <div className="absolute bottom-4 left-4 bg-white p-2 rounded-md shadow-md">
              <p className="text-sm font-semibold">Khammam District</p>
              <p className="text-xs text-gray-600">Active Delivery Zone</p>
            </div>
          </div>
          <div className="mt-4">
            <div className="bg-gray-200 h-2 rounded-full">
              <div className="bg-green-600 h-2 rounded-full w-3/4"></div>
            </div>
            <p className="text-sm text-gray-600 mt-2">Coverage Area: 75%</p>
          </div>
        </div>
      </div>
    </div>
  );
}