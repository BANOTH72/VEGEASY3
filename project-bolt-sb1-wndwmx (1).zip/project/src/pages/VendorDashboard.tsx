import React from 'react';
import { Package, TrendingUp, Users } from 'lucide-react';

export default function VendorDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Vendor Dashboard</h1>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Package className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Total Products</h2>
          <p className="text-3xl font-bold">24</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <TrendingUp className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Today's Sales</h2>
          <p className="text-3xl font-bold">₹4,500</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Users className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Active Orders</h2>
          <p className="text-3xl font-bold">8</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Inventory Management</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-semibold">Tomatoes</h3>
                <p className="text-sm text-gray-600">Stock: 50kg</p>
              </div>
              <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Update Stock
              </button>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-semibold">Potatoes</h3>
                <p className="text-sm text-gray-600">Stock: 100kg</p>
              </div>
              <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Update Stock
              </button>
            </div>
            {/* Add more inventory items */}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Recent Orders</h2>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">#ORD001</span>
                <span className="text-green-600">₹350</span>
              </div>
              <p className="text-sm text-gray-600">Customer: John Doe</p>
              <p className="text-sm text-gray-600">Items: Tomatoes, Onions, Potatoes</p>
            </div>
            <div className="border-b pb-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">#ORD002</span>
                <span className="text-green-600">₹280</span>
              </div>
              <p className="text-sm text-gray-600">Customer: Jane Smith</p>
              <p className="text-sm text-gray-600">Items: Carrots, Cabbage</p>
            </div>
            {/* Add more orders */}
          </div>
        </div>
      </div>
    </div>
  );
}