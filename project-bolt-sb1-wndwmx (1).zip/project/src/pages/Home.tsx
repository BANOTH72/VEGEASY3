import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBasket, Store, Bike } from 'lucide-react';

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="relative text-center mb-16">
        <div className="absolute inset-0 flex items-center justify-center -z-10">
          <div className="w-full h-full bg-gradient-to-r from-green-50 to-green-100 opacity-70"></div>
          <img
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80"
            alt="Vegetables background"
            className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
          />
        </div>
        <div className="relative py-20">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Fresh Vegetables, Delivered Fast
          </h1>
          <p className="text-xl text-gray-800">
            Connecting local vendors with customers through reliable delivery partners
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-8 rounded-xl shadow-md text-center transform hover:scale-105 transition-transform">
          <div className="relative mb-6">
            <img
              src="https://images.unsplash.com/photo-1557844352-761f2565b576?auto=format&fit=crop&q=80"
              alt="Fresh vegetables"
              className="w-full h-48 object-cover rounded-lg"
            />
            <ShoppingBasket className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 w-12 h-12 text-white bg-green-600 p-2 rounded-full" />
          </div>
          <h2 className="text-2xl font-semibold mb-4">Buy Fresh Vegetables</h2>
          <p className="text-gray-600 mb-6">
            Order fresh vegetables from local vendors and get them delivered to your doorstep
          </p>
          <Link
            to="/customer"
            className="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
          >
            Start Shopping
          </Link>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-md text-center transform hover:scale-105 transition-transform">
          <div className="relative mb-6">
            <img
              src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&q=80"
              alt="Vegetable vendor"
              className="w-full h-48 object-cover rounded-lg"
            />
            <Store className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 w-12 h-12 text-white bg-green-600 p-2 rounded-full" />
          </div>
          <h2 className="text-2xl font-semibold mb-4">Sell Your Vegetables</h2>
          <p className="text-gray-600 mb-6">
            List your vegetables and reach more customers in your area
          </p>
          <Link
            to="/vendor"
            className="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
          >
            Start Selling
          </Link>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-md text-center transform hover:scale-105 transition-transform">
          <div className="relative mb-6">
            <img
              src="https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&q=80"
              alt="Delivery rider"
              className="w-full h-48 object-cover rounded-lg"
            />
            <Bike className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 w-12 h-12 text-white bg-green-600 p-2 rounded-full" />
          </div>
          <h2 className="text-2xl font-semibold mb-4">Deliver With Us</h2>
          <p className="text-gray-600 mb-6">
            Join our delivery partner network and earn money on your schedule
          </p>
          <Link
            to="/rider"
            className="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
          >
            Start Delivering
          </Link>
        </div>
      </div>

      <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-12">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Why Choose VegEasy?
            </h2>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-green-600 p-2 rounded-full">
                  <ShoppingBasket className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Fresh & Local</h3>
                  <p className="text-gray-600">
                    Direct from local vendors to ensure maximum freshness
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-green-600 p-2 rounded-full">
                  <Bike className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
                  <p className="text-gray-600">
                    Quick delivery within hours of ordering
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-green-600 p-2 rounded-full">
                  <Store className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Fair Prices</h3>
                  <p className="text-gray-600">
                    Competitive prices that benefit both vendors and customers
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80"
              alt="Fresh vegetables arrangement"
              className="rounded-lg shadow-xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
              <img
                src="https://images.unsplash.com/photo-1595475207225-428b62bda831?auto=format&fit=crop&q=80"
                alt="VegEasy delivery"
                className="w-32 h-32 object-cover rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}