import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Leaf, Home } from 'lucide-react';

export default function Navbar() {
  const location = useLocation();

  return (
    <nav className="bg-green-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 hover:text-green-100 transition-colors">
            <Leaf className="h-8 w-8" />
            <span className="text-xl font-bold">VegEasy</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link 
              to="/" 
              className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors relative group
                ${location.pathname === '/' ? 'bg-green-700' : 'hover:bg-green-700'}`}
            >
              <Home className="h-5 w-5" />
              <span>Home</span>
              {location.pathname === '/' && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-white rounded-t-md"></div>
              )}
            </Link>
            <Link 
              to="/customer" 
              className={`px-3 py-2 rounded-md transition-colors relative group
                ${location.pathname === '/customer' ? 'bg-green-700' : 'hover:bg-green-700'}`}
            >
              Buy Vegetables
              {location.pathname === '/customer' && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-white rounded-t-md"></div>
              )}
            </Link>
            <Link 
              to="/vendor" 
              className={`px-3 py-2 rounded-md transition-colors relative group
                ${location.pathname === '/vendor' ? 'bg-green-700' : 'hover:bg-green-700'}`}
            >
              Sell Vegetables
              {location.pathname === '/vendor' && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-white rounded-t-md"></div>
              )}
            </Link>
            <Link 
              to="/rider" 
              className={`px-3 py-2 rounded-md transition-colors relative group
                ${location.pathname === '/rider' ? 'bg-green-700' : 'hover:bg-green-700'}`}
            >
              Become a Rider
              {location.pathname === '/rider' && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-white rounded-t-md"></div>
              )}
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}